package c.a.a;

import java.security.SecureRandom;

final class cx
  implements Runnable
{
  public final void run()
  {
    cw.b().nextInt();
    cw.c();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/cx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */