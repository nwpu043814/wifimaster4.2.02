package c.a.a;

import c.a.a.a.b;

public class aa
  extends u
{
  private byte[] a;
  
  aa(int paramInt)
  {
    super(paramInt);
  }
  
  final String a()
  {
    return "<" + b.a(this.a) + ">";
  }
  
  final void a(q paramq)
  {
    this.a = paramq.j();
  }
  
  final void a(s params)
  {
    params.a(this.a);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */