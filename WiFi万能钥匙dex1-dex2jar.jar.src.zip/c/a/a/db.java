package c.a.a;

import java.io.IOException;

public class db
  extends IOException
{
  public db() {}
  
  public db(String paramString)
  {
    super(paramString);
  }
  
  public db(String paramString, Throwable paramThrowable)
  {
    super(paramString);
    initCause(paramThrowable);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/db.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */