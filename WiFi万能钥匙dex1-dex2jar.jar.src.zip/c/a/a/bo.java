package c.a.a;

public final class bo
  extends bt
{
  private bg a;
  private bg b;
  
  final bt a()
  {
    return new bo();
  }
  
  final void a(q paramq)
  {
    this.a = new bg(paramq);
    this.b = new bg(paramq);
  }
  
  final void a(s params, l paraml, boolean paramBoolean)
  {
    this.a.a(params, null, paramBoolean);
    this.b.a(params, null, paramBoolean);
  }
  
  final String b()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(this.a);
    localStringBuffer.append(" ");
    localStringBuffer.append(this.b);
    return localStringBuffer.toString();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/bo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */