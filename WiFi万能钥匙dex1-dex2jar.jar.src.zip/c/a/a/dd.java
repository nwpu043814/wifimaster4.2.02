package c.a.a;

public final class dd
  extends Exception
{
  public dd() {}
  
  public dd(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/dd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */