package c.a.a;

public final class bj
{
  private static av a;
  
  static
  {
    av localav = new av("DNS Opcode", 2);
    a = localav;
    localav.b(15);
    a.a("RESERVED");
    a.a();
    a.a(0, "QUERY");
    a.a(1, "IQUERY");
    a.a(2, "STATUS");
    a.a(4, "NOTIFY");
    a.a(5, "UPDATE");
  }
  
  public static String a(int paramInt)
  {
    return a.d(paramInt);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/bj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */