package c.a.a;

public final class cp
{
  static void a(long paramLong)
  {
    if ((paramLong < 0L) || (paramLong > 2147483647L)) {
      throw new ag(paramLong);
    }
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/cp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */