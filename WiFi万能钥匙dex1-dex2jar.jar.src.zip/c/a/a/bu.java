package c.a.a;

public final class bu
  extends IllegalArgumentException
{
  public bu(bg parambg)
  {
    super("'" + parambg + "' is not an absolute name");
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/bu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */