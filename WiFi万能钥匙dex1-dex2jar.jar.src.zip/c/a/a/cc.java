package c.a.a;

public final class cc
  extends cq
{
  final bt a()
  {
    return new cc();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/cc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */