package c.a.a;

abstract class cv
  extends bt
{
  protected int a;
  protected bg b;
  
  final void a(q paramq)
  {
    this.a = paramq.h();
    this.b = new bg(paramq);
  }
  
  void a(s params, l paraml, boolean paramBoolean)
  {
    params.c(this.a);
    this.b.a(params, null, paramBoolean);
  }
  
  final String b()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(this.a);
    localStringBuffer.append(" ");
    localStringBuffer.append(this.b);
    return localStringBuffer.toString();
  }
  
  protected final bg d()
  {
    return this.b;
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/cv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */