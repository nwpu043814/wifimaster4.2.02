package c.a.a;

public final class ao
  extends cj
{
  final bt a()
  {
    return new ao();
  }
  
  public final bg c()
  {
    return d();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */