package c.a.a;

import java.util.EventListener;

public abstract interface by
  extends EventListener
{
  public abstract void a(au paramau);
  
  public abstract void a(Object paramObject, Exception paramException);
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/by.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */