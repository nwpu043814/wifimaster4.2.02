package c.a.a;

abstract class ci
  extends cj
{
  final void a(s params, l paraml, boolean paramBoolean)
  {
    this.a.a(params, paraml, paramBoolean);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/ci.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */