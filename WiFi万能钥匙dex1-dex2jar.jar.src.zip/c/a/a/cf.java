package c.a.a;

public final class cf
{
  private static av a = new av("Message Section", 3);
  private static String[] b = new String[4];
  private static String[] c = new String[4];
  
  static
  {
    a.b(3);
    a.a();
    a.a(0, "qd");
    a.a(1, "an");
    a.a(2, "au");
    a.a(3, "ad");
    b[0] = "QUESTIONS";
    b[1] = "ANSWERS";
    b[2] = "AUTHORITY RECORDS";
    b[3] = "ADDITIONAL RECORDS";
    c[0] = "ZONE";
    c[1] = "PREREQUISITES";
    c[2] = "UPDATE RECORDS";
    c[3] = "ADDITIONAL RECORDS";
  }
  
  public static String a(int paramInt)
  {
    return a.d(paramInt);
  }
  
  public static String b(int paramInt)
  {
    a.a(paramInt);
    return b[paramInt];
  }
  
  public static String c(int paramInt)
  {
    a.a(paramInt);
    return c[paramInt];
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/cf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */