package c.a.a;

abstract class cj
  extends bt
{
  protected bg a;
  
  final void a(q paramq)
  {
    this.a = new bg(paramq);
  }
  
  void a(s params, l paraml, boolean paramBoolean)
  {
    this.a.a(params, null, paramBoolean);
  }
  
  final String b()
  {
    return this.a.toString();
  }
  
  protected final bg d()
  {
    return this.a;
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/cj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */