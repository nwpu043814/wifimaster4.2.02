package c.a.a;

import c.a.a.a.d;

public final class n
  extends bt
{
  private byte[] a;
  
  final bt a()
  {
    return new n();
  }
  
  final void a(q paramq)
  {
    this.a = paramq.j();
  }
  
  final void a(s params, l paraml, boolean paramBoolean)
  {
    params.a(this.a);
  }
  
  final String b()
  {
    return d.a(this.a);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */