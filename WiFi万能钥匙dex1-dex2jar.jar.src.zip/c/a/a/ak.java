package c.a.a;

public final class ak
  extends cv
{
  final bt a()
  {
    return new ak();
  }
  
  public final bg c()
  {
    return d();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/c/a/a/ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */