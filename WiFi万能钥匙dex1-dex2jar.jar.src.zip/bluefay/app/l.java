package bluefay.app;

import android.content.Context;

public class l
{
  public Context a;
  
  public void a() {}
  
  public void b() {}
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */