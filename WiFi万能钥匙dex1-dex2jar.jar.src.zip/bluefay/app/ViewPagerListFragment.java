package bluefay.app;

import android.os.Bundle;
import android.view.View;

public class ViewPagerListFragment
  extends ListFragment
{
  public void onViewCreated(View paramView, Bundle paramBundle)
  {
    d();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/ViewPagerListFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */