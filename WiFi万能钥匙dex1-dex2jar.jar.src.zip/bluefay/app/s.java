package bluefay.app;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

final class s
  implements AdapterView.OnItemClickListener
{
  s(ListFragment paramListFragment) {}
  
  public final void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {}
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */