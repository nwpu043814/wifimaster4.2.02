package bluefay.app;

import android.content.Context;

public abstract interface q
{
  public abstract void a(Context paramContext);
  
  public abstract void b(Context paramContext);
  
  public abstract void c(Context paramContext);
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */