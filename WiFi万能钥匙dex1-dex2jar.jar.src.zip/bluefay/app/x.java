package bluefay.app;

import android.view.MenuItem;
import com.bluefay.widget.b;

final class x
  implements b
{
  x(w paramw) {}
  
  public final void a(MenuItem paramMenuItem)
  {
    this.a.onMenuItemSelected(0, paramMenuItem);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */