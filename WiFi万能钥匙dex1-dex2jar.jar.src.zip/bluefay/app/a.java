package bluefay.app;

import android.view.ViewGroup;

final class a
  implements Runnable
{
  a(ActionSheet paramActionSheet) {}
  
  public final void run()
  {
    ActionSheet.b(this.a).removeView(ActionSheet.a(this.a));
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */