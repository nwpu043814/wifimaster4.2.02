package bluefay.app;

import android.view.Menu;

public abstract interface o
{
  public abstract void a(int paramInt1, int paramInt2);
  
  public abstract boolean a(int paramInt, Menu paramMenu);
  
  public abstract boolean b(int paramInt, Menu paramMenu);
  
  public abstract void c(int paramInt);
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/app/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */