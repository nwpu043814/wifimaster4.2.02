package bluefay.widget;

final class b
  implements Runnable
{
  b(SlidingButton paramSlidingButton) {}
  
  public final void run()
  {
    SlidingButton.a(this.a).a(this.a.isChecked());
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/widget/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */