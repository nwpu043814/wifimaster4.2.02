package bluefay.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.CompoundButton;

public class Switch
  extends CompoundButton
{
  public Switch(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public Switch(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public Switch(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/widget/Switch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */