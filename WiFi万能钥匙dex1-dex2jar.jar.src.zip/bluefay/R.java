package bluefay;

public final class R
{
  public static final class anim
  {
    public static int framework_activity_close_enter = com.bluefay.framework.R.anim.framework_activity_close_enter;
    public static int framework_activity_close_exit = com.bluefay.framework.R.anim.framework_activity_close_exit;
    public static int framework_activity_open_enter = com.bluefay.framework.R.anim.framework_activity_open_enter;
    public static int framework_activity_open_exit = com.bluefay.framework.R.anim.framework_activity_open_exit;
    public static int framework_dialog_close_enter = com.bluefay.framework.R.anim.framework_dialog_close_enter;
    public static int framework_dialog_close_exit = com.bluefay.framework.R.anim.framework_dialog_close_exit;
    public static int framework_dialog_enter = com.bluefay.framework.R.anim.framework_dialog_enter;
    public static int framework_dialog_exit = com.bluefay.framework.R.anim.framework_dialog_exit;
    public static int framework_dialog_open_enter = com.bluefay.framework.R.anim.framework_dialog_open_enter;
    public static int framework_dialog_open_exit = com.bluefay.framework.R.anim.framework_dialog_open_exit;
    public static int framework_slide_left_enter = com.bluefay.framework.R.anim.framework_slide_left_enter;
    public static int framework_slide_left_exit = com.bluefay.framework.R.anim.framework_slide_left_exit;
    public static int framework_slide_right_enter = com.bluefay.framework.R.anim.framework_slide_right_enter;
    public static int framework_slide_right_exit = com.bluefay.framework.R.anim.framework_slide_right_exit;
  }
  
  public static final class drawable
  {
    public static int framework_list_view_item_bg = com.bluefay.framework.R.drawable.framework_list_view_item_bg;
    public static int framework_unread_bg = com.bluefay.framework.R.drawable.framework_unread_bg;
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */