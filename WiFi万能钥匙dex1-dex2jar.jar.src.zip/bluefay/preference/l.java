package bluefay.preference;

import android.os.Handler;
import android.os.Message;

final class l
  extends Handler
{
  l(PreferenceFragment paramPreferenceFragment) {}
  
  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    }
    for (;;)
    {
      return;
      PreferenceFragment.a(this.a);
    }
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */