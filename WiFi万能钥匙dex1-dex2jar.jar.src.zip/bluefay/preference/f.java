package bluefay.preference;

import android.os.Parcelable.Creator;

final class f
  implements Parcelable.Creator<ListPreference.SavedState>
{}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */