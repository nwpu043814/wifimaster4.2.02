package bluefay.preference;

import android.widget.ListView;

final class m
  implements Runnable
{
  m(PreferenceFragment paramPreferenceFragment) {}
  
  public final void run()
  {
    PreferenceFragment.b(this.a).focusableViewAvailable(PreferenceFragment.b(this.a));
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */