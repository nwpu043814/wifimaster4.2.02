package bluefay.preference;

final class p
  implements Runnable
{
  p(o paramo) {}
  
  public final void run()
  {
    o.a(this.a);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */