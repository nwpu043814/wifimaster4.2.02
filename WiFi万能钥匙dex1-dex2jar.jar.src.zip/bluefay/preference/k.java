package bluefay.preference;

import android.os.Parcelable.Creator;

final class k
  implements Parcelable.Creator<Preference.BaseSavedState>
{}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */