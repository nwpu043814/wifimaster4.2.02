package bluefay.preference;

import android.os.Parcelable.Creator;

final class h
  implements Parcelable.Creator<MultiCheckPreference.SavedState>
{}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */