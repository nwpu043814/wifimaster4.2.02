package bluefay.preference;

import bluefay.widget.SlidingButton.a;

final class a
  implements SlidingButton.a
{
  a(CheckBoxPreference paramCheckBoxPreference) {}
  
  public final void a(boolean paramBoolean)
  {
    if (paramBoolean != this.a.b) {
      this.a.a(this.a.B().d());
    }
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */