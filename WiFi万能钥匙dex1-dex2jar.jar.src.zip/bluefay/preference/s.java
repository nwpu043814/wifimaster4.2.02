package bluefay.preference;

import android.os.Parcelable.Creator;

final class s
  implements Parcelable.Creator<PreferenceScreen.SavedState>
{}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/preference/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */