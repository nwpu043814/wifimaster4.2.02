package bluefay.webkit;

import android.webkit.WebViewClient;

class WebViewActivity$5
  extends WebViewClient
{
  WebViewActivity$5(c paramc) {}
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/bluefay/webkit/WebViewActivity$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */