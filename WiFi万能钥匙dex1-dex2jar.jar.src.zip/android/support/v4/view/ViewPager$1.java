package android.support.v4.view;

import java.util.Comparator;

final class ViewPager$1
  implements Comparator<ViewPager.ItemInfo>
{
  public final int compare(ViewPager.ItemInfo paramItemInfo1, ViewPager.ItemInfo paramItemInfo2)
  {
    return paramItemInfo1.position - paramItemInfo2.position;
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/view/ViewPager$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */