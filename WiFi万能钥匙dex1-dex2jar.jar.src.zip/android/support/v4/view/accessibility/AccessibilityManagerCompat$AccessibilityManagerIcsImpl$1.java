package android.support.v4.view.accessibility;

class AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1
  implements AccessibilityManagerCompatIcs.AccessibilityStateChangeListenerBridge
{
  AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1(AccessibilityManagerCompat.AccessibilityManagerIcsImpl paramAccessibilityManagerIcsImpl, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat) {}
  
  public void onAccessibilityStateChanged(boolean paramBoolean)
  {
    this.val$listener.onAccessibilityStateChanged(paramBoolean);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */