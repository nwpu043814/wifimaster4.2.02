package android.support.v4.net;

class TrafficStatsCompat$BaseTrafficStatsCompatImpl$1
  extends ThreadLocal<TrafficStatsCompat.BaseTrafficStatsCompatImpl.SocketTags>
{
  TrafficStatsCompat$BaseTrafficStatsCompatImpl$1(TrafficStatsCompat.BaseTrafficStatsCompatImpl paramBaseTrafficStatsCompatImpl) {}
  
  protected TrafficStatsCompat.BaseTrafficStatsCompatImpl.SocketTags initialValue()
  {
    return new TrafficStatsCompat.BaseTrafficStatsCompatImpl.SocketTags(null);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */