package android.support.v4.widget;

class ViewDragHelper$2
  implements Runnable
{
  ViewDragHelper$2(ViewDragHelper paramViewDragHelper) {}
  
  public void run()
  {
    this.this$0.setDragState(0);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/widget/ViewDragHelper$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */