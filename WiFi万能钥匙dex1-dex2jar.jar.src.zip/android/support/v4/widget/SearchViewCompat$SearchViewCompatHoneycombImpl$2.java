package android.support.v4.widget;

class SearchViewCompat$SearchViewCompatHoneycombImpl$2
  implements SearchViewCompatHoneycomb.OnCloseListenerCompatBridge
{
  SearchViewCompat$SearchViewCompatHoneycombImpl$2(SearchViewCompat.SearchViewCompatHoneycombImpl paramSearchViewCompatHoneycombImpl, SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat) {}
  
  public boolean onClose()
  {
    return this.val$listener.onClose();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */