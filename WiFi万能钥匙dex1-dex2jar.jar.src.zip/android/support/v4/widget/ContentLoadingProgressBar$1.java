package android.support.v4.widget;

class ContentLoadingProgressBar$1
  implements Runnable
{
  ContentLoadingProgressBar$1(ContentLoadingProgressBar paramContentLoadingProgressBar) {}
  
  public void run()
  {
    ContentLoadingProgressBar.access$002(this.this$0, false);
    ContentLoadingProgressBar.access$102(this.this$0, -1L);
    this.this$0.setVisibility(8);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/widget/ContentLoadingProgressBar$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */