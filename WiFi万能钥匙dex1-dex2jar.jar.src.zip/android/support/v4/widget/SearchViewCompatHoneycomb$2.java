package android.support.v4.widget;

import android.widget.SearchView.OnCloseListener;

final class SearchViewCompatHoneycomb$2
  implements SearchView.OnCloseListener
{
  SearchViewCompatHoneycomb$2(SearchViewCompatHoneycomb.OnCloseListenerCompatBridge paramOnCloseListenerCompatBridge) {}
  
  public final boolean onClose()
  {
    return this.val$listener.onClose();
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/widget/SearchViewCompatHoneycomb$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */