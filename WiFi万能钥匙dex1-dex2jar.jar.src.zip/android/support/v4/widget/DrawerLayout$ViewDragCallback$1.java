package android.support.v4.widget;

class DrawerLayout$ViewDragCallback$1
  implements Runnable
{
  DrawerLayout$ViewDragCallback$1(DrawerLayout.ViewDragCallback paramViewDragCallback) {}
  
  public void run()
  {
    DrawerLayout.ViewDragCallback.access$000(this.this$1);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/widget/DrawerLayout$ViewDragCallback$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */