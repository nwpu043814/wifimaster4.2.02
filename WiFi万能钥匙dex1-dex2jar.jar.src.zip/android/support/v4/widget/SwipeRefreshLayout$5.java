package android.support.v4.widget;

class SwipeRefreshLayout$5
  implements Runnable
{
  SwipeRefreshLayout$5(SwipeRefreshLayout paramSwipeRefreshLayout) {}
  
  public void run()
  {
    SwipeRefreshLayout.access$902(this.this$0, true);
    SwipeRefreshLayout.access$1100(this.this$0, SwipeRefreshLayout.access$700(this.this$0) + this.this$0.getPaddingTop(), SwipeRefreshLayout.access$1000(this.this$0));
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/widget/SwipeRefreshLayout$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */