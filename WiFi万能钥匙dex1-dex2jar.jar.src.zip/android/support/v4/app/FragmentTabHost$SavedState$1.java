package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class FragmentTabHost$SavedState$1
  implements Parcelable.Creator<FragmentTabHost.SavedState>
{
  public final FragmentTabHost.SavedState createFromParcel(Parcel paramParcel)
  {
    return new FragmentTabHost.SavedState(paramParcel, null);
  }
  
  public final FragmentTabHost.SavedState[] newArray(int paramInt)
  {
    return new FragmentTabHost.SavedState[paramInt];
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/app/FragmentTabHost$SavedState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */