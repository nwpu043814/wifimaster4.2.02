package android.support.v4.print;

import android.os.CancellationSignal.OnCancelListener;

class PrintHelperKitkat$2$1$1
  implements CancellationSignal.OnCancelListener
{
  PrintHelperKitkat$2$1$1(PrintHelperKitkat.2.1 param1) {}
  
  public void onCancel()
  {
    PrintHelperKitkat.2.access$100(this.this$2.this$1);
    this.this$2.cancel(false);
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/android/support/v4/print/PrintHelperKitkat$2$1$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */