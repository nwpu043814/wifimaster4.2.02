package a.a.a.c.a;

public final class c
{
  private static final c a = new c();
  private a b;
  
  public static final c a()
  {
    return a;
  }
  
  public final b b()
  {
    if (this.b != null) {}
    for (b localb = this.b.a();; localb = null) {
      return localb;
    }
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/a/a/a/c/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */