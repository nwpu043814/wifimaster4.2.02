package a.a.a.c;

import java.io.IOException;

public abstract class a
{
  protected b d;
  
  public a(b paramb)
  {
    this.d = paramb;
  }
  
  protected abstract void a();
  
  protected abstract void a(IOException paramIOException);
  
  public final void b()
  {
    try
    {
      this.d.d();
      a();
      return;
    }
    catch (IOException localIOException)
    {
      for (;;)
      {
        a(localIOException);
      }
    }
  }
}


/* Location:              /Users/hanlian/Downloads/WiFi万能钥匙dex1-dex2jar.jar!/a/a/a/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */